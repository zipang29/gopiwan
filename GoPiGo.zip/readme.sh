# Décompresser le contenu cette archive dans le repertoire
#	/home/pi/

# Automatiser le démarrage : 
	cp ./script_boot.sh /usr/bin/script_boot.sh
	cp ./script_rc.sh /etc/init.d/script_boot.sh

	update-rc.d script_boot.sh 99 3
#__________________________________________________________

#Lancer manuellement le serveur : 

#java -jar GoPiGo.jar PYTHON 
