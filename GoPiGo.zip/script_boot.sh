ifdown wlan0
sleep 2
killall hostapd
sleep 2
ifup wlan0
sleep 2
hostapd /etc/hostapd/hostapd.conf &
killall java
java -jar /home/pi/GoPiGo.jar PYTHON &
