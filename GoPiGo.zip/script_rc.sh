#! /bin/sh
# /etc/init.d/script_boot.sh
#

/usr/bin/script_boot.sh
 
case "$1" in
  start)
    echo "le script démarre "
    ;;
  stop)
    echo "le script est stoppé"
    ;;
  *)
    echo "Usage: /etc/init.d/script_boot.sh {start|stop}"
    exit 1
    ;;
esac
exit 0
