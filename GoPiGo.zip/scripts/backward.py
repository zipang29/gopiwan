#!/usr/bin/env python 

import gopigo 

gopigo.bwd()
