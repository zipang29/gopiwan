#!/usr/bin/env python 

import gopigo

gopigo.decrease_speed()
