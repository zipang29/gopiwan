#!/usr/bin/env python 

import gopigo

gopigo.fwd()
