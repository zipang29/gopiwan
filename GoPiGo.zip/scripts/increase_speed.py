#!/usr/bin/env python 

import gopigo

gopigo.increase_speed()
