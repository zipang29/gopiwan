#!/usr/bin/env python 

import gopigo

gopigo.led(sys.argv[1], sys.argv[2])
