#!/usr/bin/env python 

import gopigo

gopigo.led_off(sys.argv[1])
