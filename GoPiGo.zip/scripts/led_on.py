#!/usr/bin/env python 

import gopigo

gopigo.led_on(sys.argv[1])
