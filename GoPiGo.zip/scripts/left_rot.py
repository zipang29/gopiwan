#!/usr/bin/env python 

import gopigo

gopigo.left_rot()
