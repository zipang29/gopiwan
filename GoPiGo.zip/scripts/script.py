#!/usr/bin/env python 

print "Poisson"
