#!/usr/bin/env python 

# arguemtn : speed : 0 - 255
import gopigo

gopigo.set_speed(sys.argv[1])
